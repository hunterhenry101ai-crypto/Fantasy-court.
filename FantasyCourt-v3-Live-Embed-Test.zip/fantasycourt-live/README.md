# FantasyCourt v3 — Live NBA + 4 embedded player slots

## What works
- 16 players from the supplied ESPN screenshots, including fantasy bench and IR.
- Four responsive screens, NBA public scoreboard and box score through a Netlify Function (20-second refresh).
- Automatic game selection prioritizes confirmed on-court players where feed provides `oncourt`.
- Enter an HTTPS embed URL per game; saved in this browser's localStorage.
- **Test crackstreams.mx embed** button attempts to frame its homepage as a compatibility test only. It does NOT discover game streams, establish authorization, or bypass frame restrictions.

## Publish
Deploy this folder through Git-connected Netlify, with publish directory `.` and functions directory `netlify/functions` as configured in netlify.toml. Static drag-and-drop may not deploy the function. Open your deployed HTTPS URL in iPhone Safari. Use Share > Add to Home Screen.

## Limitations
- Streaming provider may refuse iframe embedding (`X-Frame-Options`, CSP), or iPhone Safari may limit simultaneous playback. This app does not bypass restrictions.
- Live data availability and substitution accuracy depend on NBA feed; `oncourt` may be absent or delayed.
- This does not log into ESPN private league 1411369780; roster is from screenshots and needs manual updates after changes.
- The first player `M. Brown Jr.` cannot be matched reliably without confirming their full name.
- A full render refresh can reload an embedded player during scoreboard updates; persistent seamless playback needs a later architectural revision.
- Never put private ESPN cookies into this frontend or public repository.
